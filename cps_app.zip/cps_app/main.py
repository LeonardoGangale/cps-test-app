
import kivy
from kivy.uix.widget import Widget
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.anchorlayout import AnchorLayout
from kivy.uix.gridlayout import GridLayout
from kivy.uix.stacklayout import StackLayout
from kivy.metrics import dp
from kivy.properties import StringProperty
from kivy.properties import BooleanProperty
from kivy.properties import NumericProperty
from kivy.core.window import Window 
from kivy.uix.behaviors import ButtonBehavior
from kivy.uix.image import Image
from time import sleep
from threading import Thread
from math import *
# librerie:
# kivy
# time
# threading
# math

if __name__=="__main__":

    Window.size = (500, 900)

    class MainStackLayout(StackLayout):
        counter = StringProperty("0")
        cps = 0
        seconds = 0
        seconds_text = NumericProperty(0)
        i = 0
        in_time = BooleanProperty(True)
        
        def timer(self):
            sleep(0.01)
            self.seconds += 0.01
            self.seconds_text = round(self.seconds, 1)
            print(f"\r{str(self.seconds)}", end="\r")
            if float(self.seconds) < 5:
                self.timer()
            
            if self.seconds_text < 5:
                self.in_time = True
            else:
                self.in_time = False

        def button_click(self):
            self.i += 1
            self.counter = str(self.i)
            if self.i == 1:
                t = Thread(target=self.timer)
                t.start()

        def restart(self):
            self.counter = "0"
            self.cps = 0
            self.seconds = 0
            self.seconds_text = 0
            self.i = 0
            self.in_time = True

    class ImageButton(ButtonBehavior, Image):
        pass

    class primoApp(App):
        pass

    primoApp().run()